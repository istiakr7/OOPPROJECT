package oopproject;
import java.util.Scanner;
public class Main {
            public static void main(String[] args) {
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter your Mobile Number:");
            int number=sc.nextInt();
            System.out.println("Enter PIN Number:");
            int pin=sc.nextInt();
            System.out.println("Welcome to your Acoount:");
           MobileBank obj1=new MobileBank(number,pin);
            obj1.menu();
        }
    }

