package oopproject;
import java.util.Scanner;
public class MobileBank {
    double bal;
    double prevTrans;
    int number;
    int pin;

    MobileBank(int number, int pin) {
        this.number = number;
        this.pin = pin;
    }

    void Cash_In(double amount) {
        if (amount != 0) {
            bal += amount;
            prevTrans = amount;
        }
    }

    void Cash_Out(double amt) {
        if (amt != 0 && bal >= amt) {
            bal -= amt;
            prevTrans = -amt;
        } else if (bal < amt) {
            System.out.println("Account balance insufficient");
        }
    }

    void Recharge(double amtr) {
        if (amtr != 0 && bal >= amtr) {
            bal -= amtr;
            prevTrans = -amtr;
        } else if (bal < amtr) {
            System.out.println("Account balance insufficient");
        }
    }

    void Payment(double amtp) {
        if (amtp != 0 && bal >= amtp) {
            bal -= amtp;
            prevTrans = -amtp;
        } else if (bal < amtp) {
            System.out.println("Bank balance insufficient");
        }
    }

    void getPreviousTrans() {
        if (prevTrans > 0) {
            System.out.println("Cash In: " + prevTrans);
        } else if (prevTrans < 0) {
            System.out.println("Last Transaction: " + Math.abs(prevTrans));
        } else {
            System.out.println("No transaction occured");
        }
    }

    void menu() {
        char option;
        Scanner sc = new Scanner(System.in);

        System.out.println("\n");
        System.out.println("a) Check Balance");
        System.out.println("b) Cash In ");
        System.out.println("c) Cash Out ");
        System.out.println("d) Payment");
        System.out.println("e) Recharge");
        System.out.println("f) Last Transaction");
        System.out.println("g) Exit");

        do {
            System.out.println("********************************************");
            System.out.println("Choose an option");
            option = sc.next().charAt(0);//char return to 0 index
            System.out.println("\n");

            switch (option) {
                case 'a':
                    System.out.println("......................");
                    System.out.println("Balance =" + bal);
                    System.out.println("......................");
                    System.out.println("\n");
                    break;
                case 'b':
                    System.out.println("......................");
                    System.out.println("Enter a amount for Cash In :");
                    System.out.println("......................");
                    double amt = sc.nextDouble();
                    Cash_In(amt);
                    System.out.println("\n");
                    break;
                case 'c':
                    System.out.println("......................");
                    System.out.println("Enter a amount for Cash Out :");
                    System.out.println("......................");
                    double amtW = sc.nextDouble();
                    Cash_Out(amtW);
                    System.out.println("\n");
                    break;

                case 'd':
                    System.out.println("......................");
                    System.out.println("Enter a amount for Payment :");
                    System.out.println("......................");
                    double amtp = sc.nextDouble();
                    Payment(amtp);
                    System.out.println("\n");
                    break;
                case 'f':
                    System.out.println("......................");
                    System.out.println("Last Transaction:");
                    getPreviousTrans();
                    System.out.println("......................");
                    System.out.println("\n");
                    break;
                case 'e':
                    System.out.println("......................");
                    System.out.println("Enter the number:");
                    int num = sc.nextInt();
                    System.out.println("......................");
                    System.out.println("Enter a amount for Recharge:");
                    double amtr = sc.nextDouble();
                    Recharge(amtr);
                    System.out.println("\n");
                    break;
                case 'g':
                    System.out.println("......................");
                    break;
                default:
                    System.out.println("Choose a correct option to proceed");
                    break;
            }

        } while (option != 'g');

        System.out.println("Thank you for using our banking services");
    }

}

